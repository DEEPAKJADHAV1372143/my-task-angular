import { DecimalvalidaitonDirective } from './decimalvalidaiton.directive';

describe('DecimalvalidaitonDirective', () => {
  it('should create an instance', () => {
    const directive = new DecimalvalidaitonDirective();
    expect(directive).toBeTruthy();
  });
});
