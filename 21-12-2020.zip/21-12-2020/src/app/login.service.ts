import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  
  constructor(private api_ser:HttpClient) { }

  userLogin(data){
    return this.api_ser.post("http://localhost/angular_tool_api_php/User/signup.php",data);
  }
  userSignIn(data){
    return this.api_ser.post("http://localhost/angular_tool_api_php/User/login.php",data);
  }
  Update(data){
    return this.api_ser.post("http://localhost/angular_tool_api_php/User/update.php/"+data.id,data);
  }
  
  googleData(data){
    return this.api_ser.post("http://localhost/angular_tool_api_php/User/googlesignup.php",data);
  }
}
