import { LoginService } from './../login.service';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { stringify } from 'querystring';
import { Router, RouterLink } from '@angular/router';


import { SocialAuthService } from "angularx-social-login";
import { FacebookLoginProvider, GoogleLoginProvider } from "angularx-social-login";
import { SocialUser } from "angularx-social-login";


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  form= new FormGroup({
    email:new FormControl('',Validators.required),
    password:new FormControl('',Validators.required)
  });
  constructor(private apiSer:LoginService, private router:Router,private authService: SocialAuthService) { }
 loginMsg:any;

 user: SocialUser;
 loggedIn: boolean;
data:any;
 signInWithGoogle(): void {
  this.authService.signIn(GoogleLoginProvider.PROVIDER_ID).then((response)=>{
 this.data=response;
 this.storeGoogleData(this.data);
 sessionStorage.setItem("googledata",JSON.stringify(this.data));
 localStorage.setItem("Checking_no","1");
 this.router.navigate(['/Home']);
  });
 
  }
  signInWithFB(): void {
  this.authService.signIn(FacebookLoginProvider.PROVIDER_ID);
  }
  signOut(): void {
  this.authService.signOut();
  }
 
storeGoogleData(data){
 this.apiSer.googleData(data);
}



 gotolink(){
   this.router.navigate(['/Resetpass'])
 }
  signIn(){
    let data =this.form.value;
    this.apiSer.userSignIn(data).subscribe((response)=>{
     this.loginMsg=response;

     localStorage.setItem("user",this.loginMsg.email);
     localStorage.setItem("pass",this.loginMsg.password);
     localStorage.setItem("Checking",this.loginMsg.status);
     localStorage.setItem("Checking_no",this.loginMsg.id);
     localStorage.setItem("alldata",JSON.stringify(this.loginMsg));
     if(this.loginMsg.status==true){
     this.router.navigate(['/Home']);
     }
    })
    
    







  }



  
  errFun() {
    let key = Object.keys(this.form.controls);
     key.filter(data=>{
       let control= this.form.controls[data];
       if(control.errors !=null){
         control.markAsTouched();
       }
     })
   }
 
   login_api(data){
     this.apiSer.userLogin(data).subscribe((response)=>{
      
     })
   }

  
  obj:object;
  login(obj){
    this.obj=obj;
  }
 
  ngOnInit(): void {
    this.authService.authState.subscribe((user) => {
      this.user = user;
      this.loggedIn = (user != null);
      });
     
    
  }

}
