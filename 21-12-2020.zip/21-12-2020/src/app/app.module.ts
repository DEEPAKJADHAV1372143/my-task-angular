

import { SocialAuthService } from 'angularx-social-login';
import { HttpClientModule } from '@angular/common/http';

import { LoginApiService } from './login-api.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DemoComponent } from './demo/demo.component';

import { from } from 'rxjs';
import { HomePageComponent } from './home-page/home-page.component';
import { ResetpassComponent } from './resetpass/resetpass.component';
import { ResetlinkComponent } from './resetlink/resetlink.component';
//this is the google code
import { SocialLoginModule, SocialAuthServiceConfig  } from 'angularx-social-login';
import {
 GoogleLoginProvider,
 FacebookLoginProvider
} from 'angularx-social-login';



//this is the google code
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    DemoComponent,
    HomePageComponent,
    ResetpassComponent,
    ResetlinkComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    SocialLoginModule

    

  ],
  providers: [LoginApiService,
    
    {
      provide: 'SocialAuthServiceConfig',
      useValue: {
      autoLogin: false,
      providers: [
      {
      id: GoogleLoginProvider.PROVIDER_ID,
      provider: new GoogleLoginProvider(
      '194278599076-g145v773dj1a33giefs267k61tr4f5a8.apps.googleusercontent.com'
      )
      },
      {
      id: FacebookLoginProvider.PROVIDER_ID,
      provider: new FacebookLoginProvider('clientId')
      }
      ]
      } as SocialAuthServiceConfig,
      }],
  bootstrap: [AppComponent]
})

export class AppModule { }
