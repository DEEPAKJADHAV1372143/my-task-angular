import { LoginService } from './../login.service';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  form= new FormGroup({
    contact:new FormControl('',Validators.required),
    full_name:new FormControl('',Validators.required),
    email:new FormControl('',Validators.required),
    password_confirm:new FormControl('',Validators.required),
    password:new FormControl('',Validators.required)
  })
  constructor(private apiSer:LoginService) { }

feedbak:any;



  login_api(){
    let data =this.form.value;
    this.apiSer.userLogin(data).subscribe((response)=>{
     this.feedbak=response;
   
    })
  }
  
  onSubmit() {
   let key = Object.keys(this.form.controls);
    key.filter(data=>{
      let control= this.form.controls[data];
      if(control.errors !=null){
        control.markAsTouched();
      }
    })
  }
  obj:object;
  Get_data(obj){
    this.obj=obj;
    console.log(this.obj);
  }
  
  ngOnInit(): void {
    
    
  }

}
