import { LoginService } from './../login.service';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.css']
})
export class HomePageComponent implements OnInit {

  constructor(private router:Router, private apiSer:LoginService) { }
 
  logOut(){
    localStorage.removeItem('Checking');
    this.router.navigate(["/Login"]);
  }

  
  userid='';
  user='';
  pass='';
  allData:object;
  form= new FormGroup({
    Full_name:new FormControl('',Validators.required),
    Moblie:new FormControl('',[Validators.required,Validators.minLength(10)]),
    id:new FormControl('',Validators.required),
    Address:new FormControl('',Validators.required),
    Email:new FormControl('',[Validators.required,Validators.email])
  });
  errFun() {
    let key = Object.keys(this.form.controls);
     key.filter(data=>{
       let control= this.form.controls[data];
       if(control.errors !=null){
         control.markAsTouched();
       }
     });
   }
   signIn(){
    let data =this.form.value;
    this.apiSer.Update(data).subscribe(()=>{

    });
   }
   objectData=[{email:this.user},{password:this.pass}];
   getAll:object;
   getData(){
   this.apiSer.userSignIn(this.objectData).subscribe(()=>{
    });
   }
  dummy;
  ngOnInit(): void {
    this.userid=localStorage.getItem("Checking_no");
    this.user=localStorage.getItem("user");
    this.pass=localStorage.getItem("pass");
    this.dummy=JSON.parse(localStorage.getItem("alldata"));
    
    this.getData();
  }

}
