import { LoginService } from './../login.service';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { stringify } from 'querystring';
import { Router, RouterLink } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  form= new FormGroup({
    email:new FormControl('',Validators.required),
    password:new FormControl('',Validators.required)
  });
  constructor(private apiSer:LoginService, private router:Router) { }
 loginMsg:any;

  signIn(){
    let data =this.form.value;
    this.apiSer.userSignIn(data).subscribe((response)=>{
     this.loginMsg=response;

     localStorage.setItem("user",this.loginMsg.email);
     localStorage.setItem("pass",this.loginMsg.password);
     localStorage.setItem("Checking",this.loginMsg.status);
     localStorage.setItem("Checking_no",this.loginMsg.id);
     localStorage.setItem("alldata",JSON.stringify(this.loginMsg));
     if(this.loginMsg.status==true){
     this.router.navigate(['/Home']);
     }
    })
    
  }



  
  errFun() {
    let key = Object.keys(this.form.controls);
     key.filter(data=>{
       let control= this.form.controls[data];
       if(control.errors !=null){
         control.markAsTouched();
       }
     })
   }
 
   login_api(data){
     this.apiSer.userLogin(data).subscribe((response)=>{
       console.log("data is come..");
     })
   }

  
  obj:object;
  login(obj){
    this.obj=obj;
  }
  ngOnInit(): void {
  
    
  }

}
