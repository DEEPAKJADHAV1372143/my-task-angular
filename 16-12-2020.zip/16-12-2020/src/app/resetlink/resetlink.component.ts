import { Router } from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resetlink',
  templateUrl: './resetlink.component.html',
  styleUrls: ['./resetlink.component.css']
})
export class ResetlinkComponent implements OnInit {

  
  constructor(private router:Router) { }
  form= new FormGroup({
    
    password:new FormControl('',Validators.required)
  })
  ngOnInit(): void {
  }

}
