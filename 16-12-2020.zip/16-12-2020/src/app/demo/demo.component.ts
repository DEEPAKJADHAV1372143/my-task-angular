import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.css']
})
export class DemoComponent implements OnInit {
form= new FormGroup({
  firstName:new FormControl('',Validators.required),
  lastName:new FormControl('',Validators.required)
})
  constructor() { }

  ngOnInit(): void {
  }

}
