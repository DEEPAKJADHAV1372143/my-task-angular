import { ResetlinkComponent } from './resetlink/resetlink.component';
import { ResetpassComponent } from './resetpass/resetpass.component';
import { AuthGuardGuard } from './auth-guard.guard';
import { HomePageComponent } from './home-page/home-page.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { AppComponent } from './app.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {path:'', redirectTo:'Register' , pathMatch:'full'},
  {path:'Loginpage' ,component: LoginComponent},
  {path:'Resetpass' ,component: ResetpassComponent},
  {path:'Resetlink' ,component: ResetlinkComponent},
  {path:'Home' ,component: HomePageComponent,canActivate : [AuthGuardGuard] },
  {path:'Register' ,component: RegisterComponent}  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
