import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resetpass',
  templateUrl: './resetpass.component.html',
  styleUrls: ['./resetpass.component.css']
})
export class ResetpassComponent implements OnInit {

  constructor(private router:Router) { }
  form= new FormGroup({
    
    email:new FormControl('',[Validators.required, Validators.email])
  })
  sendEmail(){
    alert("link has been sent to your email check it .");
    this.router.navigate(['/Loginpage'])
  }
  ngOnInit(): void {
  }

}
